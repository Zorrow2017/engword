package com.example.readertxt;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

public class BookTextActivity extends AppCompatActivity {
    private int curpage=0,maxpage=1;
    MyTTSUtil booktts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_text);

        final String filepath=getIntent().getStringExtra("filepath");
        TextView showbookinfo=findViewById(R.id.show_bookinfo);
        showbookinfo.setText(filepath==null?"null":filepath);
        final Button bb_openEng = findViewById(R.id.button_openEng);
        Button bb_readPsg=findViewById(R.id.button_readpsg);
        Button bb_stopRead=findViewById(R.id.button_psgreadstop);
        final SeekBar bb_bookProcess=findViewById(R.id.seekBar_bookprocess);
        Button bb_bookList=findViewById(R.id.button_booklist);
        Button bb_readStream=findViewById(R.id.button_flowlisten);
        final TextView text_bookProcess=findViewById(R.id.text_bookprocess);
        //
        bb_openEng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView text_engPsg=findViewById(R.id.text_englishPsg);
                                File bookdir=new File("/storage/emulated/0/mybook");
                if (bookdir.mkdir()){
                        File bookeng=new File("/storage/emulated/0/mybook/eng.txt");
                        if (!bookeng.exists()){
                            try{
                                InputStream bookins=getResources().openRawResource(R.raw.eng);
                                FileOutputStream bookouts=new FileOutputStream(bookeng);
                                byte[] tempdata=new byte[1024];
                                int blen=1024;
                                while (blen==1024){
                                    blen=bookins.read(tempdata);
                                    bookouts.write(tempdata,0,blen);
                                }
                                bookouts.close();
                                bookins.close();
                            }catch (IOException e) {
                                Log.d("readertxt_mainDebug","file eng read/write failure! ");
                                e.printStackTrace();
                            }
                        }
                }else{
                    //Log.d("readertxt_mainDebug","file eng dir mkdir failure! ");
                }
                String strb="";
                try {
//                    FileInputStream bookins=new FileInputStream("/storage/emulated/0/mybook/eng.txt");
//                    ByteArrayOutputStream byteb=new ByteArrayOutputStream();
//                    byte[] tempread=new byte[1024];
//                    int lenb=1024;
//                    while (lenb==1024){
//                        lenb=bookins.read(tempread);
//                        byteb.write(tempread,0,lenb);
//                    }
//                    //Log.d("readertxt_mainDebug","size="+byteb.size());
//                    strb=byteb.toString("utf-8");
                    FileReader bookins=new FileReader("/storage/emulated/0/mybook/eng.txt");
                    char[] tempread=new char[1024];
                    int lenb,maxpage=1;
                    for (int i=0;i<curpage;i++){
                        lenb=bookins.read(tempread);
                        if (lenb==0){
                            maxpage=i;
                            break;
                        }
                    }
                     lenb=bookins.read(tempread);
                    if (lenb<=0){
                        tempread="Over Page, please press read again. ".toCharArray();
                        lenb=tempread.length;
                        curpage%=maxpage;
                    }else{
                        curpage++;
                    }
                    bookins.close();
                    text_engPsg.setText(tempread,0,lenb);
                    text_engPsg.setMovementMethod(ScrollingMovementMethod.getInstance());
                } catch (FileNotFoundException e) {
                    Log.d("readertxt_mainDebug","storage file not find");
                    e.printStackTrace();
                } catch (IOException e) {
                    Log.d("readertxt_mainDebug","storage file read failure! ");
                    e.printStackTrace();
                }
//                if (strb.isEmpty()){
//                    strb="null data";
//                    text_engPsg.setText(strb);
//                }

            }
        });
        bb_readPsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView text_engPsg=findViewById(R.id.text_englishPsg);
                booktts=new MyTTSUtil(BookTextActivity.this);
                booktts.speech(text_engPsg.getText().toString());
            }
        });
        bb_stopRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (booktts!=null) {
                    booktts.stop();
                }
            }
        });
        bb_bookProcess.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                text_bookProcess.setText(String.format("%.1f%%",progress*100.0/seekBar.getMax()));
                curpage=Math.round(maxpage*progress*1.0f/seekBar.getMax());
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });
        text_bookProcess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text_bookProcess.setText(String.format("%.1f%%",curpage*1.0/maxpage));
            }
        });
        bb_bookList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bookc=new Intent(BookTextActivity.this,BookListActivity.class);
                bookc.putExtra("filepath",filepath);
                startActivityForResult(bookc,1);
            }
        });
        bb_readStream.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //bb_bookProcess.setProgress(200);
                String f2=filepath+"";
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}
